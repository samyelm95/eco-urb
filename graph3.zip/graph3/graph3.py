import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
from roman import toRoman

def plot_schools_on_paris_map(nbcollege_lyceeparis):
    # Charger le fichier CSV en DataFrame
    data = pd.read_csv(nbcollege_lyceeparis)

    # Charger la carte de Paris
    paris_map = gpd.read_file("arrondissements.geojson")

    # Fusionner les données avec la carte de Paris
    paris_map = paris_map.merge(data, how='left', left_on='c_ar', right_on='arrondissement')

    # Remplacer les valeurs NaN par 0
    paris_map.fillna(0, inplace=True)

    # Trier les données pour le tracé de la carte
    paris_map.sort_values(by=['nombre_de_college', 'nombre_de_lycee'], ascending=True, inplace=True)

    # Normaliser les données pour la coloration
    min_schools = min(paris_map['nombre_de_college'].min(), paris_map['nombre_de_lycee'].min())
    max_schools = max(paris_map['nombre_de_college'].max(), paris_map['nombre_de_lycee'].max())
    norm = plt.Normalize(min_schools, max_schools)
    cmap = plt.cm.Blues  # Vous pouvez choisir une autre carte de couleur si vous le souhaitez

    # Créer une figure
    fig, ax = plt.subplots(figsize=(10, 10))

    # Tracer la carte de Paris avec une coloration basée sur le nombre total d'établissements scolaires
    paris_map.plot(ax=ax, column='nombre_de_college', cmap=cmap, edgecolor='black', linewidth=0.5, legend=True, legend_kwds={'label': "Nombre total d'établissements scolaires"})

    # Ajouter un titre
    ax.set_title("Concentration d'établissements scolaire dans Paris")

    # Ajouter le numéro des arrondissements en chiffres romains
    for idx, row in paris_map.iterrows():
        ax.text(row.geometry.centroid.x, row.geometry.centroid.y, toRoman(int(row.c_ar)), horizontalalignment='center', fontsize=8)

    # Ajouter les noms des axes
    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')

    # Afficher la carte
    plt.show()

# Utilisation de la fonction avec le fichier CSV en paramètre
plot_schools_on_paris_map('nbcollege_lyceeparis.csv')
