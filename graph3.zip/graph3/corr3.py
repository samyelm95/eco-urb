import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Charger les données depuis le fichier CSV
data = pd.read_csv("nbcollege_lyceeparis2.csv")

# Calculer le coefficient de corrélation
correlation = np.corrcoef(data['nombre_de_college'] + data['nombre_de_lycee'], data['prix'])[0, 1]

# Créer le graphique de corrélation
plt.scatter(data['nombre_de_college'] + data['nombre_de_lycee'], data['prix'])
plt.title('Corrélation entre le nombre d\'établissements scolaires et le prix de l\'immobilier dans chaque arrondissement de Paris en 2024')
plt.xlabel('Nombre total d\'établissements scolaires (collèges + lycées)')
plt.ylabel('Prix de l\'immobilier dans l\'arrondissement (€/m²)')
plt.text(0.1, 0.9, f'Corrélation : {correlation:.2f}', transform=plt.gca().transAxes)

# Calculer les limites de l'axe des x et y
x_min = min(data['nombre_de_college'] + data['nombre_de_lycee'])
x_max = max(data['nombre_de_college'] + data['nombre_de_lycee'])
y_min = min(data['prix'])
y_max = max(data['prix'])

# Tracer la droite de corrélation parfaite (coefficient de corrélation = 1)
plt.plot([x_min, x_max], [y_min, y_max], color='k', linestyle='-', label='Droite de corrélation parfaite (r=1)')
plt.legend(loc='lower right')

plt.show()



