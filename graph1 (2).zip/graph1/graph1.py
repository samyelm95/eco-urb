import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np

# Charger les données géographiques de l'Île-de-France
france_map = gpd.read_file(gpd.datasets.get_path('naturalearth_cities'))
idf_map = france_map[france_map['name'].isin(['Paris', 'Versailles', 'Fontainebleau', 'Melun', 'Évry'])]

# Charger les contours des départements d'Île-de-France
idf_departments = gpd.read_file("georef-france-departement-millesime.shp")  # Remplacez "idf_departments.shp" par le chemin de votre fichier

# Convertir les prix par mètre carré en couleurs
cmap = plt.cm.Reds

# Installer les bibliothèques et définir la fonction
def plot_points_on_map(csv_file):
    # Charger le fichier CSV en DataFrame
    data = pd.read_csv(csv_file)

    # Créer une figure
    fig, ax = plt.subplots(figsize=(10, 10))

    # Tracer les contours des départements
    idf_departments.plot(ax=ax, edgecolor='black', alpha=0.2)

    # Tracer la carte de l'Île-de-France
    idf_map.plot(ax=ax, color='lightgrey')

    # Convertir les prix par mètre carré en couleurs
    min_price = data['Prix/m²'].min()
    max_price = data['Prix/m²'].max()
    norm = plt.Normalize(min_price, max_price)

    # Définir une fonction pour gérer les clics sur les points
    def on_click(event):
        if event.inaxes == ax:
            for annotation in ax.texts:
                annotation.set_visible(False)
            for index, row in data.iterrows():
                place = row['Place']
                school = row['Nom du Lycée']
                city = row['Ville']
                lat = row['Latitude']
                lon = row['Longitude']
                price_per_sqm = row['Prix/m²']
                rank = index + 1  # Rang à partir de 1
                size = 150 - 5 * np.log(rank)  # Plus le rang est élevé, plus le point est gros

                if event.xdata - 0.02 <= lon <= event.xdata + 0.02 and event.ydata - 0.02 <= lat <= event.ydata + 0.02:
                    ax.annotate(text=f'{school}\n{place}', xy=(lon, lat), xytext=(5, 5), textcoords='offset points', ha='left', va='bottom', fontsize=8, color='black', bbox=dict(facecolor='white', alpha=0.7))
                    ax.figure.canvas.draw()
                    break

    # Connecter la fonction on_click à l'événement de clic de la souris
    fig.canvas.mpl_connect('button_press_event', on_click)

    # Ajouter des points sur la carte en fonction du prix/m²
    legend_added = False  # Variable pour suivre si la légende a été ajoutée
    for index, row in data.iterrows():
        lat = row['Latitude']
        lon = row['Longitude']
        price_per_sqm = row['Prix/m²']
        rank = index + 1  # Rang à partir de 1
        size = 150 - 5 * np.log(rank)  # Plus le rang est élevé, plus le point est gros

        # Plot
        if rank <= 10:  # Si c'est l'un des 10 meilleurs lycées, afficher une étoile
            ax.scatter(lon, lat, color='gold', marker='*', s=150, label='Top 10 Lycées')  # Ajout du label pour la légende
            if not legend_added:  # Ajouter la légende uniquement si elle n'a pas déjà été ajoutée
                ax.legend()
                legend_added = True
        else:
            ax.scatter(lon, lat, color=cmap(norm(price_per_sqm)), s=size)

    # Ajouter une légende pour les prix/m²
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax)
    cbar.set_label('Prix/m²')

    # Afficher le titre et les labels
    ax.set_title('Répartion du Top 100 lycées de France || Focus IDF')
    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')

    # Afficher la carte
    plt.show()

# Utilisation de la fonction avec le fichier CSV en paramètre
plot_points_on_map('lyceeidf.csv')

