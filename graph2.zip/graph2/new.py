import csv

# Charger les données des prix dans un dictionnaire
nouveaux_prix = {
    "1er Arrondissement": 13570,
    "2e Arrondissement": 12450,
    "3e Arrondissement": 12500,
    "4e Arrondissement": 13380,
    "5e Arrondissement": 13230,
    "6e Arrondissement": 15400,
    "7e Arrondissement": 15000,
    "8e Arrondissement": 13030,
    "9e Arrondissement": 11550,
    "10e Arrondissement": 10410,
    "11e Arrondissement": 10740,
    "12e Arrondissement": 9980,
    "13e Arrondissement": 9520,
    "14e Arrondissement": 10560,
    "15e Arrondissement": 10530,
    "16e Arrondissement": 11860,
    "17e Arrondissement": 11110,
    "18e Arrondissement": 10000,
    "19e Arrondissement": 8920,
    "20e Arrondissement": 9400
}

# Ouvrir le fichier CSV et mettre à jour les prix
with open('data_lyceeparis.csv', mode='r', newline='') as infile:
    reader = csv.DictReader(infile)
    rows = list(reader)
    for row in rows:
        arrondissement = row['arrondissement']
        if arrondissement in nouveaux_prix:
            row['prix_arrondissement'] = nouveaux_prix[arrondissement]

# Écrire les données mises à jour dans un nouveau fichier CSV
with open('new.csv', mode='w', newline='') as outfile:
    writer = csv.DictWriter(outfile, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Le fichier a été mis à jour avec succès !")
