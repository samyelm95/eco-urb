import pandas as pd
import matplotlib.pyplot as plt

# Charger les données depuis le fichier CSV
data = pd.read_csv("data_lyceeparis.csv")

# Calculer le coefficient de corrélation entre les variables
correlation = data['classement'].corr(data['prix_arrondissement'])

# Trouver les valeurs moyennes pour ajuster la droite
x_mean = data['classement'].mean()
y_mean = data['prix_arrondissement'].mean()

# Calculer la pente
numerator = sum((data['classement'] - x_mean) * (data['prix_arrondissement'] - y_mean))
denominator = sum((data['classement'] - x_mean) ** 2)
slope = numerator / denominator

# Calculer l'ordonnée à l'origine
intercept = y_mean - slope * x_mean

# Définir les valeurs de x pour la droite
x_values = data['classement']

# Calculer les valeurs de y correspondantes en utilisant l'équation de la droite
y_values = slope * x_values + intercept

# Créer le graphique de corrélation
plt.scatter(data['classement'], data['prix_arrondissement'])
plt.plot(x_values, y_values, color='black', linestyle='-', label='Droite de corrélation imparfaite')
plt.title('Corrélation entre le classement des l\'école et le prix de l\'immobilier dans leur secteur à Paris en 2024')
plt.xlabel('Classement de l\'école')
plt.ylabel('Prix de l\'immobilier dans l\'arrondissement')
plt.text(0.1, 0.9, f'Corrélation : {correlation:.2f}', transform=plt.gca().transAxes)
plt.legend(loc='upper right')
plt.show()
