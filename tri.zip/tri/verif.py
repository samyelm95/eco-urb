import geopandas as gpd

# Charger le fichier GeoJSON de Paris
paris_map = gpd.read_file("arrondissements.geojson")

# Afficher les premières lignes pour vérifier les noms de colonnes
print(paris_map.head())
