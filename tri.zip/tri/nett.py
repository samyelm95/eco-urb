import pandas as pd

def nettoyer_csv(arrondissementspar):
    # Charger le fichier CSV en tant que DataFrame
    df = pd.read_csv(arrondissementspar, sep=';')
    
    # Supprimer les lignes vides
    df = df.dropna(how='all')
    
    # Vérifier la présence des colonnes obligatoires
    colonnes_obligatoires = ['college', 'lycee', 'prix', 'Identifiant séquentiel de l’arrondissement', 
                             'arrondissement', 'Numéro d’arrondissement INSEE', 'Nom de l’arrondissement', 
                             'Nom officiel de l’arrondissement', 'N_SQ_CO', 'Surface', 'Périmètre', 
                             'Geometry X Y', 'Geometry']
    
    colonnes_manquantes = [colonne for colonne in colonnes_obligatoires if colonne not in df.columns]
    
    if colonnes_manquantes:
        print("Colonnes manquantes : ", colonnes_manquantes)
        return None
    
    # Retourner le DataFrame nettoyé
    return df

# Utilisation de la fonction pour nettoyer le fichier CSV
nom_fichier = "arrondissementspar.csv"  # Remplacez "votre_fichier.csv" par le nom de votre fichier CSV
df_nettoye = nettoyer_csv("arrondissementspar.csv")

if df_nettoye is not None:
    # Écrire le DataFrame nettoyé dans un nouveau fichier CSV
    df_nettoye.to_csv("fichier_nettoye.csv", index=False)
    print("Fichier nettoyé créé avec succès.")
