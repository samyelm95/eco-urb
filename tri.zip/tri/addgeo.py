import json

# Charger le shapefile de la France
france_geojson = 'dep.geojson'
map_df = gpd.read_file('dep.geojson')

# Convertir les géométries en chaînes de caractères JSON
map_df['geometry_str'] = map_df['geometry'].apply(lambda x: json.dumps(x.__geo_interface__))

# Charger les données CSV
data = pd.read_csv('datadep.csv')

# Fusionner les données avec les géométries
data_with_geometry = pd.merge(data, map_df[['Geometry', 'geometry_str']], on='Geometry')

# Enregistrer les données avec la colonne geometry dans un nouveau CSV
data_with_geometry.to_csv('datadep_with_geometry.csv', index=False)
