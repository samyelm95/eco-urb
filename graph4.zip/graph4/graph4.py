import matplotlib.pyplot as plt

# Données
data = {
    'Paris': {'Année': [1980, 1995, 2011, 2018], 'Nombre d\'établissements': [340000, 400000, 500000, 550000], 'Prix immobilier': [3000, 4500, 8000, 10000]},
    'Marseille': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [80000, 90000, 100000, 110000, 120000], 'Prix immobilier': [1000, 1500, 2000, 3000, 3500]},
    'Lyon': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [90000, 100000, 110000, 120000, 130000], 'Prix immobilier': [1200, 1800, 2500, 3500, 4500]},
    'Toulouse': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [40000, 50000, 60000, 70000, 80000], 'Prix immobilier': [800, 1200, 1500, 2500, 3000]},
    'Nice': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [50000, 60000, 70000, 80000, 90000], 'Prix immobilier': [1500, 2000, 3000, 4000, 5000]}
}

# Graphique pour le nombre d'établissements par ville
plt.figure(figsize=(10, 6))
for ville, valeurs in data.items():
    plt.plot(valeurs['Année'], valeurs['Nombre d\'établissements'], label=ville)

plt.title('Évolution du nombre d\'établissements par ville')
plt.xlabel('Année')
plt.ylabel('Nombre d\'établissements')
plt.legend()
plt.grid(True)
plt.show()

# Graphique pour le prix de l'immobilier par ville
plt.figure(figsize=(10, 6))
for ville, valeurs in data.items():
    plt.plot(valeurs['Année'], valeurs['Prix immobilier'], label=ville)

plt.title('Évolution du prix de l\'immobilier par ville')
plt.xlabel('Année')
plt.ylabel('Prix immobilier (€/m²)')
plt.legend()
plt.grid(True)
plt.show()
