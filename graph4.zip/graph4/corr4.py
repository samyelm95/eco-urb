import matplotlib.pyplot as plt
import numpy as np

# Données
data = {
    'Paris': {'Année': [1980, 1995, 2011, 2018], 'Nombre d\'établissements': [340000, 400000, 500000, 550000], 'Prix immobilier': [3000, 4500, 8000, 10000]},
    'Marseille': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [80000, 90000, 100000, 110000, 120000], 'Prix immobilier': [1000, 1500, 2000, 3000, 3500]},
    'Lyon': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [90000, 100000, 110000, 120000, 130000], 'Prix immobilier': [1200, 1800, 2500, 3500, 4500]},
    'Toulouse': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [40000, 50000, 60000, 70000, 80000], 'Prix immobilier': [800, 1200, 1500, 2500, 3000]},
    'Nice': {'Année': [1980, 1990, 2000, 2010, 2018], 'Nombre d\'établissements': [50000, 60000, 70000, 80000, 90000], 'Prix immobilier': [1500, 2000, 3000, 4000, 5000]}
}

# Collecte des données pour le calcul de la corrélation
nb_etablissements = []
prix_immobilier = []

for ville, valeurs in data.items():
    nb_etablissements.extend(valeurs['Nombre d\'établissements'])
    prix_immobilier.extend(valeurs['Prix immobilier'])

# Calcul de la corrélation générale
correlation_generale = np.corrcoef(nb_etablissements, prix_immobilier)[0, 1]

# Création du graphique
plt.figure(figsize=(8, 6))
plt.scatter(nb_etablissements, prix_immobilier, color='skyblue')
plt.title('Corrélation générale : {:.2f}'.format(correlation_generale))
plt.xlabel('Nombre d\'établissements')
plt.ylabel('Prix immobilier')
plt.grid(True)
plt.show()


